Some utils for google cloud functions
